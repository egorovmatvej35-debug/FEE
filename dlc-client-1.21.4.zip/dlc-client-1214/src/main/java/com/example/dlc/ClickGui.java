package com.example.dlc;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

/** LMB on a module = toggle, RMB = expand settings, drag a slider to change a value. */
public class ClickGui extends Screen {
    private static final int X = 20, Y = 20, W = 140, ROW = 14, SROW = 12;
    private Setting dragging;

    public ClickGui() { super(Text.literal("DLC Client")); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        ctx.fill(X, Y, X + W, Y + ROW, 0xFF0E7490);
        ctx.drawTextWithShadow(textRenderer, "DLC Client", X + 4, Y + 3, 0xFFFFFF);
        int y = Y + ROW;
        for (Module m : DlcClient.MODULES) {
            ctx.fill(X, y, X + W, y + ROW, m.enabled ? 0xFF2E7D32 : 0xFF222222);
            ctx.drawTextWithShadow(textRenderer, m.name, X + 4, y + 3, 0xFFFFFF);
            if (!m.settings.isEmpty()) {
                ctx.drawTextWithShadow(textRenderer, m.expanded ? "-" : "+", X + W - 10, y + 3, 0xAAAAAA);
            }
            y += ROW;
            if (m.expanded) {
                for (Setting s : m.settings) {
                    ctx.fill(X, y, X + W, y + SROW, 0xFF111111);
                    int fillW = (int) ((W - 4) * (s.value - s.min) / (s.max - s.min));
                    ctx.fill(X + 2, y + SROW - 3, X + 2 + fillW, y + SROW - 1, 0xFF22D3EE);
                    ctx.drawTextWithShadow(textRenderer,
                            s.name + ": " + String.format(Locale.ROOT, "%.2f", s.value), X + 4, y + 1, 0xCCCCCC);
                    y += SROW;
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (mx < X || mx > X + W) return super.mouseClicked(mx, my, button);
        int y = Y + ROW;
        for (Module m : DlcClient.MODULES) {
            if (my >= y && my < y + ROW) {
                if (button == 0) m.enabled = !m.enabled;
                else if (button == 1 && !m.settings.isEmpty()) m.expanded = !m.expanded;
                return true;
            }
            y += ROW;
            if (m.expanded) {
                for (Setting s : m.settings) {
                    if (my >= y && my < y + SROW && button == 0) {
                        dragging = s;
                        setFromMouse(s, mx);
                        return true;
                    }
                    y += SROW;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            setFromMouse(dragging, mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    private void setFromMouse(Setting s, double mx) {
        double t = MathHelper.clamp((mx - X - 2) / (W - 4), 0.0, 1.0);
        s.value = s.min + (s.max - s.min) * t;
    }

    @Override
    public boolean shouldPause() { return false; }
}
