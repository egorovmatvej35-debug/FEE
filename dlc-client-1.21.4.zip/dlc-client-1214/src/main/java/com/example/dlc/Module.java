package com.example.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final int defaultKey;
    public final List<Setting> settings = new ArrayList<>();
    public boolean enabled;
    public boolean expanded;
    public KeyBinding key;

    protected Module(String name, int defaultKey) {
        this.name = name;
        this.defaultKey = defaultKey;
    }

    protected Setting add(String n, double min, double max, double def) {
        Setting s = new Setting(n, min, max, def);
        settings.add(s);
        return s;
    }

    public abstract void onTick(MinecraftClient mc);
}
