package com.example.dlc;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class DlcClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();
    private static boolean shiftWasDown;

    @Override
    public void onInitializeClient() {
        MODULES.add(new AimAssist());
        MODULES.add(new TriggerBot());
        MODULES.add(new AutoClicker());
        MODULES.add(new AutoSprint());

        for (Module m : MODULES) {
            m.key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.dlc." + m.name.toLowerCase(), InputUtil.Type.KEYSYM, m.defaultKey, "category.dlc"));
        }

        // /dlc opens the ClickGUI (works even if the key doesn't)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("dlc").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new ClickGui()));
                    return 1;
                })));

        // Message in chat on join so you can see the mod is loaded
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> client.execute(() ->
                client.inGameHud.getChatHud().addMessage(
                        Text.literal("[DLC] loaded. Right Shift or /dlc opens the ClickGUI."))));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            // Right Shift is polled directly, no keybinding system involved
            boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (down && !shiftWasDown) {
                if (mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGui());
                else if (mc.currentScreen instanceof ClickGui) mc.setScreen(null);
            }
            shiftWasDown = down;

            if (mc.player == null || mc.world == null) return;
            for (Module m : MODULES) {
                while (m.key.wasPressed()) m.enabled = !m.enabled;
                if (m.enabled) m.onTick(mc);
            }
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            int w = mc.getWindow().getScaledWidth();
            int y = 4;
            ctx.drawTextWithShadow(mc.textRenderer, "DLC", w - mc.textRenderer.getWidth("DLC") - 4, y, 0x55FFFF);
            y += 11;
            for (Module m : MODULES) {
                if (!m.enabled) continue;
                ctx.drawTextWithShadow(mc.textRenderer, m.name, w - mc.textRenderer.getWidth(m.name) - 4, y, 0xFFFFFF);
                y += 10;
            }
        });
    }
}
