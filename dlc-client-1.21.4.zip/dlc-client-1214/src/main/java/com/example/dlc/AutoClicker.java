package com.example.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/** While LMB is held and the crosshair is on an entity, attacks at the configured CPS. */
public class AutoClicker extends Module {
    private final Setting cps = add("CPS", 1, 20, 10);
    private final Setting jitter = add("Jitter", 0, 5, 1.5);
    private final Random rng = new Random();
    private double acc;

    public AutoClicker() { super("AutoClicker", GLFW.GLFW_KEY_H); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || mc.interactionManager == null || !mc.options.attackKey.isPressed()) {
            acc = 0;
            return;
        }
        double rate = Math.max(1, cps.value + (rng.nextDouble() * 2 - 1) * jitter.value);
        acc += rate / 20.0;
        if (acc >= 1) {
            acc -= 1;
            if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity le && le.isAlive()) {
                mc.interactionManager.attackEntity(p, le);
                p.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
