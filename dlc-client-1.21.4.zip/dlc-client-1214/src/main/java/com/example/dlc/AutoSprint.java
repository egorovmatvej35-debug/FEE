package com.example.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.lwjgl.glfw.GLFW;

public class AutoSprint extends Module {
    public AutoSprint() { super("AutoSprint", GLFW.GLFW_KEY_V); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.input.movementForward > 0 && !p.horizontalCollision && !p.isSneaking()
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
