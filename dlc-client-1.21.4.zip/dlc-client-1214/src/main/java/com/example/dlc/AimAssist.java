package com.example.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Smoothly pulls the crosshair toward the nearest target while attack key is held. */
public class AimAssist extends Module {
    private final Setting range = add("Range", 1, 8, 5.0);
    private final Setting fov = add("FOV", 10, 180, 70);
    private final Setting smooth = add("Smooth", 0.05, 1, 0.25);
    private final Setting maxStep = add("MaxStep", 1, 20, 6);

    public AimAssist() { super("AimAssist", GLFW.GLFW_KEY_R); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;

        LivingEntity best = null;
        float bestAngle = (float) fov.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == p || !le.isAlive()) continue;
            if (p.distanceTo(le) > range.value) continue;
            float[] r = rotationTo(p, le);
            float angle = Math.abs(MathHelper.wrapDegrees(r[0] - p.getYaw()));
            if (angle < bestAngle) { bestAngle = angle; best = le; }
        }
        if (best == null) return;

        float step = (float) maxStep.value;
        float k = (float) smooth.value;
        float[] r = rotationTo(p, best);
        float dYaw = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dPitch = r[1] - p.getPitch();
        p.setYaw(p.getYaw() + MathHelper.clamp(dYaw * k, -step, step));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dPitch * k, -step, step), -90f, 90f));
    }

    private static float[] rotationTo(ClientPlayerEntity p, Entity t) {
        Vec3d eye = p.getEyePos();
        Vec3d c = t.getBoundingBox().getCenter();
        double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{yaw, pitch};
    }
}
